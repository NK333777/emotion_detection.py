# Emotion Detection with Watson NLP

A Flask web application that uses the Watson NLP library to detect
emotions (anger, disgust, fear, joy, sadness) in a piece of text and
reports the dominant emotion.

## Project structure
- `EmotionDetection/emotion_detection.py` — core function calling the Watson NLP EmotionPredict service
- `EmotionDetection/__init__.py` — package init exposing `emotion_detector`
- `test_emotion_detection.py` — unit tests covering all five emotions
- `server.py` — Flask app exposing `/` and `/emotionDetector`
- `templates/index.html`, `static/mywebscript.js` — front end
